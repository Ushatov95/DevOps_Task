import os
import logging
import datetime
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.mgmt.network import NetworkManagementClient
from azure.data.tables import TableServiceClient, UpdateMode
from azure.mgmt.resource import SubscriptionClient

def main(req: func.HttpRequest) -> func.HttpResponse:
    utc_timestamp = datetime.datetime.utcnow().isoformat()
    logging.info(f"VNet scan function triggered manually at {utc_timestamp}")

    try:
        table_name = os.environ["TABLE_STORAGE_NAME"]
        storage_url = os.environ["TABLE_STORAGE_URL"]

        credential = DefaultAzureCredential()

        # Get subscription ID dynamically
        subscription_client = SubscriptionClient(credential)
        sub_id = next(subscription_client.subscriptions.list()).subscription_id

        net_client = NetworkManagementClient(credential, sub_id)
        table_service = TableServiceClient(endpoint=storage_url, credential=credential)
        table_client = table_service.get_table_client(table_name)

        count = 0
        for vnet in net_client.virtual_networks.list_all():
            for subnet in vnet.subnets:
                entity = {
                    "PartitionKey": "vnets",
                    "RowKey": f"{vnet.name}-{subnet.name}-{datetime.datetime.utcnow().timestamp()}",
                    "VNetName": vnet.name,
                    "SubnetName": subnet.name,
                    "AddressPrefix": ",".join(subnet.address_prefixes) if subnet.address_prefixes else subnet.address_prefix,
                    "ResourceGroup": vnet.id.split("/")[4]
                }
                table_client.upsert_entity(entity, mode=UpdateMode.MERGE)
                count += 1

        logging.info(f"{count} records written to table storage.")
        return func.HttpResponse(f"Successfully processed and saved {count} entries.", status_code=200)

    except Exception as e:
        logging.error(f"Error occurred: {e}")
        return func.HttpResponse(f"Function failed with error: {e}", status_code=500)
